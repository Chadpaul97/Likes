var clicks = 0;
var clicks1 = 0;
var clicksss = 0;




function onClick() {
    clicks += 1;
    document.getElementById("clicks").innerHTML = clicks;
};


function onClick1() {
    clicks1 += 1;
    document.getElementById("clicks1").innerHTML = clicks1;
};




function onClick2() {
    clicksss += 1;
    document.getElementById("clicksss").innerHTML = clicksss;
};

